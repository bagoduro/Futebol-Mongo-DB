from pymongo import MongoClient

def conectar():
    uri = "mongodb+srv://pedroraposo1999:p7vW42URGbmownJp@mongodb.5nasz.mongodb.net/?retryWrites=true&w=majority&appName=mongodb"
    conn = MongoClient(uri)
    return conn

def adicionar_jogo_completo(rodada, numero_jogo, time_casa, time_visitante, data, hora, estadio, gols_casa, gols_visitante):
    conn = conectar()
    db = conn['futebol']

    resultado = f"{gols_casa} x {gols_visitante}"
    vencedor = time_casa if gols_casa > gols_visitante else time_visitante if gols_visitante > gols_casa else "Empate"

    db.jogos.insert_one({
        "Rodada": rodada,
        "Número do Jogo": numero_jogo,
        "Time Casa": time_casa,
        "Time Visitante": time_visitante,
        "Data": data,
        "Hora": hora,
        "Estádio": estadio,
        "Resultado": resultado,
        "Vencedor": vencedor,
        "Gols Time Casa": gols_casa,
        "Gols Time Visitante": gols_visitante
    })
    conn.close()

def editar_jogo(rodada, numero_jogo, campo, novo_valor):
    conn = conectar()
    db = conn['futebol']

    # Convertendo rodada e número_jogo para strings para compatibilidade
    rodada = str(rodada)
    numero_jogo = str(numero_jogo)

    # Mapear campos para atualização
    campos_mapeados = {
        "2": "Time Casa",
        "3": "Time Visitante",
        "4": "Data",
        "5": "Hora",
        "6": "Estádio",
        "7": "Gols Time Casa",
        "8": "Gols Time Visitante"
    }

    if campo == "1":  # Apagar Jogo
        result = db.jogos.delete_one({"Rodada": rodada, "Número do Jogo": numero_jogo})
        if result.deleted_count > 0:
            print("Jogo apagado com sucesso.")
            atualizar_resultado_parcial()
            calcular_classificacao()
        else:
            print("Nenhum jogo encontrado para apagar.")
        conn.close()
        return

    # Verificar se o campo está mapeado
    if campo not in campos_mapeados and campo not in ["7", "8", "9"]:
        print("Opção inválida. Por favor, selecione uma opção válida.")
        conn.close()
        return

    # Verificar se o jogo existe
    jogo = db.jogos.find_one({"Rodada": rodada, "Número do Jogo": numero_jogo})
    if not jogo:
        print(f"Jogo na rodada {rodada} com número {numero_jogo} não encontrado.")
        conn.close()
        return

    # Preparar campos para atualização
    update_fields = {}

    # Atualizar Time Casa ou Time Visitante
    # Atualizar Time Casa ou Time Visitante
    if campo in ["2", "3"]:
        update_fields[campos_mapeados[campo]] = novo_valor

    # Obter o nome atualizado para time_casa e time_visitante
        time_casa = novo_valor if campo == "2" else jogo["Time Casa"]
        time_visitante = novo_valor if campo == "3" else jogo["Time Visitante"]

    # Recalcular vencedor
        vencedor = determine_vencedor(jogo["Gols Time Casa"], jogo["Gols Time Visitante"], time_casa, time_visitante)
        update_fields["Time Casa"] = time_casa
        update_fields["Time Visitante"] = time_visitante
        update_fields["Vencedor"] = vencedor


    # Atualizar apenas Gols Time Casa
    elif campo == "7":
        gols_time_casa = int(novo_valor)
        gols_time_visitante = jogo["Gols Time Visitante"]
        resultado = f"{gols_time_casa} x {gols_time_visitante}"
        vencedor = determine_vencedor(gols_time_casa, gols_time_visitante, jogo["Time Casa"], jogo["Time Visitante"])

        update_fields = {
            "Gols Time Casa": gols_time_casa,
            "Resultado": resultado,
            "Vencedor": vencedor
        }

    # Atualizar apenas Gols Time Visitante
    elif campo == "8":
        gols_time_visitante = int(novo_valor)
        gols_time_casa = jogo["Gols Time Casa"]
        resultado = f"{gols_time_casa} x {gols_time_visitante}"
        vencedor = determine_vencedor(gols_time_casa, gols_time_visitante, jogo["Time Casa"], jogo["Time Visitante"])

        update_fields = {
            "Gols Time Visitante": gols_time_visitante,
            "Resultado": resultado,
            "Vencedor": vencedor
        }

    # Atualizar gols de ambos os times
    elif campo == "9":
        # Descompactar a tupla diretamente
        gols_time_casa, gols_time_visitante = novo_valor
        resultado = f"{gols_time_casa} x {gols_time_visitante}"
        vencedor = determine_vencedor(gols_time_casa, gols_time_visitante, jogo["Time Casa"], jogo["Time Visitante"])

        update_fields = {
            "Gols Time Casa": gols_time_casa,
            "Gols Time Visitante": gols_time_visitante,
            "Resultado": resultado,
            "Vencedor": vencedor
        }

    else:  # Atualizar outros campos mapeados
        update_fields[campos_mapeados[campo]] = novo_valor

    # Atualizar o documento no banco de dados
    result = db.jogos.update_one(
        {"Rodada": rodada, "Número do Jogo": numero_jogo},
        {"$set": update_fields}
    )

    if result.matched_count == 0:
        print(f"Nenhum documento foi encontrado para Rodada {rodada} e Número do Jogo {numero_jogo}.")
    elif result.modified_count > 0:
        print("Documento atualizado com sucesso.")
    else:
        print("Nenhuma alteração foi feita no documento.")

    # Recalcular resultados e classificação
    atualizar_resultado_parcial()
    calcular_classificacao()

    conn.close()

def determine_vencedor(gols_casa, gols_visitante, time_casa, time_visitante):

    if gols_casa > gols_visitante:
        return time_casa
    elif gols_visitante > gols_casa:
        return time_visitante
    return "Empate"



def atualizar_resultado_parcial():
    conn = conectar()
    db = conn['futebol']

    # Limpa os resultados parciais anteriores
    db.resultados_parciais.delete_many({})
    games = db.jogos.find()

    teams_stats = {}

    for game in games:
        home_team = game['Time Casa']
        away_team = game['Time Visitante']
        home_goals = game['Gols Time Casa']
        away_goals = game['Gols Time Visitante']
        rodada = game["Rodada"]
        numero_jogo = game["Número do Jogo"]

        # Inicializa estatísticas para cada time, incluindo rodada e número do jogo
        for team in [home_team, away_team]:
            if team not in teams_stats:
                teams_stats[team] = {
                    "Pontos": 0, "Vitórias": 0, "Empates": 0, "Derrotas": 0,
                    "Gols Marcados": 0, "Gols Sofridos": 0, "Saldo de Gols": 0,
                    "Rodada": rodada, "Número do Jogo": numero_jogo  # Adicionando Rodada e Número do Jogo
                }

        # Atualizar estatísticas de gols
        teams_stats[home_team]["Gols Marcados"] += home_goals
        teams_stats[home_team]["Gols Sofridos"] += away_goals
        teams_stats[away_team]["Gols Marcados"] += away_goals
        teams_stats[away_team]["Gols Sofridos"] += home_goals

        teams_stats[home_team]["Saldo de Gols"] = teams_stats[home_team]["Gols Marcados"] - teams_stats[home_team]["Gols Sofridos"]
        teams_stats[away_team]["Saldo de Gols"] = teams_stats[away_team]["Gols Marcados"] - teams_stats[away_team]["Gols Sofridos"]

        # Atualizar pontuação e resultados
        if home_goals > away_goals:
            teams_stats[home_team]["Pontos"] += 3
            teams_stats[home_team]["Vitórias"] += 1
            teams_stats[away_team]["Derrotas"] += 1
        elif away_goals > home_goals:
            teams_stats[away_team]["Pontos"] += 3
            teams_stats[away_team]["Vitórias"] += 1
            teams_stats[home_team]["Derrotas"] += 1
        else:
            teams_stats[home_team]["Pontos"] += 1
            teams_stats[away_team]["Pontos"] += 1
            teams_stats[home_team]["Empates"] += 1
            teams_stats[away_team]["Empates"] += 1

    # Ordenar e inserir no banco, incluindo rodada e número do jogo
    sorted_teams = sorted(teams_stats.items(), key=lambda team: (
        team[1]["Pontos"], 
        team[1]["Vitórias"], 
        team[1]["Saldo de Gols"], 
        team[1]["Gols Marcados"]
    ), reverse=True)

    for team, stats in sorted_teams:
        stats["Time"] = team  # Adicionando o identificador do time
        db.resultados_parciais.insert_one(stats)

    conn.close()


def calcular_classificacao():
    conn = conectar()
    db = conn['futebol']
    db.classificacao.delete_many({})

    partial_results = db.resultados_parciais.find().sort([
        ("Pontos", -1),
        ("Vitórias", -1),
        ("Saldo de Gols", -1),
        ("Gols Marcados", -1)
    ])
    
    for pos, result in enumerate(partial_results, start=1):
        result["Posição"] = pos
        db.classificacao.insert_one(result)

    conn.close()

def exibir_classificacao():
    conn = conectar()
    db = conn['futebol']
    doc = db.times.find_one()
    id_to_name = {str(time["id"]): time["nome"] for time in doc["times"]} if doc and "times" in doc else {}
    classificacao = list(db.classificacao.find().sort("Posição", 1))
    print("Classificação:")
    for time in classificacao:
        team_name = id_to_name.get(str(time['Time']), f"ID {time['Time']} não encontrado")
        print(f"{time['Posição']}. {team_name}: {time['Pontos']} pontos, {time['Vitórias']} vitórias, {time['Saldo de Gols']} saldo de gols, {time['Gols Marcados']} gols marcados")
    conn.close()

def exibir_times_com_numeros():
    conn = conectar()
    db = conn['futebol']

    # Buscar os times disponíveis no banco
    doc = db.times.find_one()

    if doc and "times" in doc:
        print("Times disponíveis:")
        for time in doc["times"]:
            team_id = str(time.get("id", "N/A"))  # Garantir que o ID seja tratado como string
            team_name = time.get("nome", "N/A")
            print(f"{team_id}: {team_name}")
    else:
        print("Nenhum time encontrado ou estrutura de dados incorreta.")
    
    conn.close()


def listar_partidas():
    conn = conectar()
    db = conn['futebol']

    # Obtenha a lista de times com seus IDs e nomes
    doc = db.times.find_one()
    id_to_name = {str(time["id"]): time["nome"] for time in doc["times"]} if doc and "times" in doc else {}

    rodadas = db.jogos.distinct("Rodada")
    print("Todas as Partidas por Rodada:")
    for rodada in sorted(rodadas):
        print(f"Rodada {rodada}:")
        jogos = db.jogos.find({"Rodada": rodada})
        for jogo in jogos:
            # Converta IDs para nomes garantindo que ambos os lados estejam como strings
            time_casa = id_to_name.get(str(jogo['Time Casa']), f"{jogo['Time Casa']}")
            time_visitante = id_to_name.get(str(jogo['Time Visitante']), f"{jogo['Time Visitante']}")
            vencedor = id_to_name.get(str(jogo['Vencedor']), "Empate") if jogo['Vencedor'] != "Empate" else "Empate"

            # Exiba os detalhes do jogo
            print(f"Rodada: {jogo['Rodada']}")
            print(f"Número do Jogo: {jogo['Número do Jogo']}")
            print(f"Time Casa: {time_casa} vs Time Visitante: {time_visitante}")
            print(f"Data: {jogo['Data']}")
            print(f"Hora: {jogo['Hora']}")
            print(f"Estádio: {jogo['Estádio']}")
            print(f"Resultado: {jogo['Resultado']}")
            print(f"Vencedor: {vencedor}")
            print(f"Gols - Time Casa: {jogo['Gols Time Casa']}, Time Visitante: {jogo['Gols Time Visitante']}")
            print("-" * 50)  # Separador para legibilidade

    conn.close()


def ver_rodada_especifica(rodada):
    conn = conectar()
    db = conn['futebol']

    # Ensure `rodada` is a string to match the database format
    rodada = str(rodada)

    # Load the team list to create an ID-to-name mapping
    doc = db.times.find_one()
    id_to_name = {str(time["id"]): time["nome"] for time in doc["times"]} if doc and "times" in doc else {}

    # Fetch the games of the specified round
    jogos = list(db.jogos.find({"Rodada": rodada}))
    if jogos:
        print(f"Jogos da Rodada {rodada}:")
        for jogo in jogos:
            # Replace team IDs with names using `id_to_name`
            time_casa = id_to_name.get(jogo['Time Casa'], jogo['Time Casa'])
            time_visitante = id_to_name.get(jogo['Time Visitante'], jogo['Time Visitante'])
            vencedor = id_to_name.get(jogo['Vencedor'], jogo['Vencedor'])
            
            # Print match details in the specified format
            print(f"Rodada: {rodada}")
            print(f"Número do Jogo: {jogo['Número do Jogo']}")
            print(f"Time Casa: {time_casa} vs Time Visitante: {time_visitante}")
            print(f"Data: {jogo['Data']}")
            print(f"Hora: {jogo['Hora']}")
            print(f"Estádio: {jogo['Estádio']}")
            print(f"Resultado: {jogo['Resultado']}")
            print(f"Vencedor: {vencedor}")
            print(f"Gols - Time Casa: {jogo['Gols Time Casa']}, Time Visitante: {jogo['Gols Time Visitante']}")
            print("\n" + "-" * 40 + "\n")  # Separator for readability
    else:
        print(f"Nenhum jogo encontrado para a rodada {rodada}.")
    
    conn.close()





def ver_jogos_time(time_id):
    conn = conectar()
    db = conn['futebol']
    
    # Carregar o mapeamento de times com seus nomes
    doc = db.times.find_one()
    id_to_name = {str(time["id"]): time["nome"] for time in doc["times"]} if doc and "times" in doc else {}

    # Validar se o ID do time existe
    team_name = id_to_name.get(str(time_id))  # Converte o ID para string
    if not team_name:
        print(f"ID {time_id} não encontrado nos times cadastrados.")
        conn.close()
        return

    # Normalizar o ID para comparação (string e int)
    time_id_str = str(time_id)
    time_id_int = int(time_id)

    # Buscar jogos onde o time é Casa ou Visitante
    jogos = list(db.jogos.find({
        "$or": [
            {"Time Casa": time_id_str},  # Caso armazenado como string
            {"Time Casa": time_id_int},  # Caso armazenado como número
            {"Time Visitante": time_id_str},  # Caso armazenado como string
            {"Time Visitante": time_id_int}  # Caso armazenado como número
        ]
    }))

    # Exibir os jogos encontrados
    if jogos:
        print(f"Jogos do time {team_name}:")
        for jogo in jogos:
            time_casa = id_to_name.get(str(jogo['Time Casa']), f"ID {jogo['Time Casa']} não encontrado")
            time_visitante = id_to_name.get(str(jogo['Time Visitante']), f"ID {jogo['Time Visitante']} não encontrado")
            print(f"Rodada {jogo['Rodada']}: {time_casa} {jogo['Resultado']} {time_visitante}")
            print(f"Data: {jogo['Data']}, Hora: {jogo['Hora']}, Estádio: {jogo['Estádio']}")
            print("-" * 50)
    else:
        print(f"Nenhum jogo encontrado para o time {team_name}.")

    conn.close()


def listar_rodadas():
    conn = conectar()
    db = conn['futebol']
    
    # Load the team list to create an ID-to-name mapping
    doc = db.times.find_one()
    id_to_name = {str(time["id"]): time["nome"] for time in doc["times"]} if doc and "times" in doc else {}
    
    rodadas = db.jogos.find().sort("Rodada", 1)
    
    rodada_atual = None
    for jogo in rodadas:
        if rodada_atual != jogo["Rodada"]:
            rodada_atual = jogo["Rodada"]
            print(f"\nRodada: {rodada_atual}")
        
        # Replace team IDs with names using `id_to_name`
        time_casa = id_to_name.get(jogo['Time Casa'], jogo['Time Casa'])
        time_visitante = id_to_name.get(jogo['Time Visitante'], jogo['Time Visitante'])
        vencedor = id_to_name.get(jogo['Vencedor'], jogo['Vencedor'])
        
        # Format the result as `{Time Casa} {Gols Time Casa} x {Gols Time Visitante} {Time Visitante}`
        resultado_formatado = f"{time_casa} {jogo['Gols Time Casa']} x {jogo['Gols Time Visitante']} {time_visitante}"
        
        # Print all match details in the specified format
        print(f"Número do Jogo: {jogo['Número do Jogo']}")
        print(f"Time Casa: {time_casa} vs Time Visitante: {time_visitante}")
        print(f"Data: {jogo['Data']}")
        print(f"Hora: {jogo['Hora']}")
        print(f"Estádio: {jogo['Estádio']}")
        print(f"Resultado: {resultado_formatado}")
        print(f"Vencedor: {vencedor}")
        print(f"Gols - Time Casa: {jogo['Gols Time Casa']}, Time Visitante: {jogo['Gols Time Visitante']}")
        print("-" * 50)  # Separator for readability
    
    conn.close()



def listar_jogos_rodada(rodada):
    conn = conectar()
    db = conn['futebol']
    jogos = db.jogos.find({"Rodada": rodada}).sort("Número do Jogo", 1)

    print(f"Rodada: {rodada}")
    for jogo in jogos:
        print(f"Número do Jogo: {jogo['Número do Jogo']}")
        print(f"Time Casa: {jogo['Time Casa']} vs Time Visitante: {jogo['Time Visitante']}")
        print(f"Data: {jogo['Data']}")
        print(f"Hora: {jogo['Hora']}")
        print(f"Estádio: {jogo['Estádio']}")
        print(f"Resultado: {jogo['Resultado']}")
        print(f"Vencedor: {jogo['Vencedor']}")
        print(f"Gols - Time Casa: {jogo['Gols Time Casa']}, Time Visitante: {jogo['Gols Time Visitante']}")
        print("-" * 50)
    conn.close()

def listar_jogos_time(time):
    conn = conectar()
    db = conn['futebol']
    jogos = db.jogos.find({"$or": [{"Time Casa": time}, {"Time Visitante": time}]}).sort("Rodada", 1)

    rodada_atual = None
    for jogo in jogos:
        if rodada_atual != jogo["Rodada"]:
            rodada_atual = jogo["Rodada"]
            print(f"Rodada: {rodada_atual}")
        print(f"Número do Jogo: {jogo['Número do Jogo']}")
        print(f"Time Casa: {jogo['Time Casa']} vs Time Visitante: {jogo['Time Visitante']}")
        print(f"Data: {jogo['Data']}")
        print(f"Hora: {jogo['Hora']}")
        print(f"Estádio: {jogo['Estádio']}")
        print(f"Resultado: {jogo['Resultado']}")
        print(f"Vencedor: {jogo['Vencedor']}")
        print(f"Gols - Time Casa: {jogo['Gols Time Casa']}, Time Visitante: {jogo['Gols Time Visitante']}")
        print("-" * 50)
    conn.close()
