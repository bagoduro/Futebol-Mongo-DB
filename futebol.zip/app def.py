from banco_dados import (
    adicionar_jogo_completo,
    editar_jogo,
    atualizar_resultado_parcial,
    calcular_classificacao,
    exibir_classificacao,
    listar_partidas,
    ver_rodada_especifica,
    ver_jogos_time,
    exibir_times_com_numeros
)

def menu_principal():
    while True:
        print("\nMenu:")
        print("1. Mostrar resultado parcial")
        print("2. Ver rodadas")
        print("3. Ver rodada específica")
        print("4. Ver jogos de um time específico")
        print("5. Editar tabela")
        print("6. Cadastrar jogos")
        print("7. Sair")
        
        opcao = input("Escolha uma opção: ").strip()

        if opcao == '1':
            atualizar_resultado_parcial()
            calcular_classificacao()
            exibir_classificacao()

        elif opcao == '2':
            listar_partidas()

        elif opcao == '3':
            rodada = input("Digite o número da rodada: ").strip()
            if rodada.isdigit():
                ver_rodada_especifica(int(rodada))
            else:
                print("Por favor, insira um número válido para a rodada.")

        elif opcao == '4':
            exibir_times_com_numeros()
            time = input("Digite o número do time: ").strip()
            if time.isdigit():
                ver_jogos_time(str(time))
            else:
                print("Por favor, insira um número válido para o time.")

        elif opcao == '5':
            rodada = input("Digite o número da rodada do jogo a ser editado: ").strip()
            numero_jogo = input("Digite o número do jogo na rodada: ").strip()
            
            if not rodada.isdigit() or not numero_jogo.isdigit():
                print("Por favor, insira números válidos para a rodada e o número do jogo.")
                continue

            rodada = int(rodada)
            numero_jogo = int(numero_jogo)
            
            print("\nO que deseja editar?")
            print("1. Apagar Jogo")
            print("2. Time Casa")
            print("3. Time Visitante")
            print("4. Data")
            print("5. Hora")
            print("6. Estádio")
            print("7. Gols Time Casa")
            print("8. Gols Time Visitante")
            print("9. Gols Time Casa e Gols Time Visitante")
            
            campo = input("Escolha uma opção: ").strip()
            
            if campo == "1":
                editar_jogo(rodada, numero_jogo, campo, None)
            elif campo in ["2", "3"]:
                exibir_times_com_numeros()
                novo_valor = input("Digite o número do novo time: ").strip()
                if novo_valor.isdigit():
                    editar_jogo(rodada, numero_jogo, campo, int(novo_valor))
                else:
                    print("Valor inválido. Por favor, insira um número.")
            elif campo in ["4", "5", "6"]:
                novo_valor = input("Digite o novo valor: ").strip()
                editar_jogo(rodada, numero_jogo, campo, novo_valor)
            elif campo in ["7", "8"]:
                novo_valor = input("Digite o novo valor numérico: ").strip()
                if novo_valor.isdigit():
                    editar_jogo(rodada, numero_jogo, campo, int(novo_valor))
                else:
                    print("Valor inválido. Por favor, insira um número.")
            elif campo == "9":
                try:
                    gols_casa = int(input("Novo Gols Time Casa: ").strip())
                    gols_visitante = int(input("Novo Gols Time Visitante: ").strip())
                    editar_jogo(rodada, numero_jogo, campo, (gols_casa, gols_visitante))
                except ValueError:
                    print("Por favor, insira valores numéricos válidos para os gols.")

        elif opcao == '6':
            rodada = input("Rodada: ").strip()
            numero_jogo = input("Número do Jogo: ").strip()
            exibir_times_com_numeros()
            time_casa = input("Digite o número do Time Casa: ").strip()
            time_visitante = input("Digite o número do Time Visitante: ").strip()
            data = input("Data (dd/mm/aaaa): ").strip()
            hora = input("Hora (hh:mm): ").strip()
            estadio = input("Estádio: ").strip()
            try:
                gols_casa = int(input("Gols Time Casa: ").strip())
                gols_visitante = int(input("Gols Time Visitante: ").strip())
                adicionar_jogo_completo(rodada, numero_jogo, time_casa, time_visitante, data, hora, estadio, gols_casa, gols_visitante)
            except ValueError:
                print("Por favor, insira valores numéricos válidos para os gols.")

        elif opcao == '7':
            print("Saindo do sistema...")
            break

        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    menu_principal()
