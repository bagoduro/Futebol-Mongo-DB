import io
import sys
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from banco_dados import (
    adicionar_jogo_completo,
    atualizar_resultado_parcial,
    calcular_classificacao,
    exibir_classificacao,
    listar_partidas,
    ver_rodada_especifica,
    ver_jogos_time,
    exibir_times_com_numeros,
    editar_jogo,
)

# Variável global para capturar os times disponíveis uma única vez
TIMES_DISPONIVEIS = None

# Função para capturar saídas de funções que utilizam print
def capturar_saida(func, *args, **kwargs):
    """Captura o texto impresso por uma função."""
    buffer = io.StringIO()
    sys.stdout = buffer
    try:
        func(*args, **kwargs)
    finally:
        sys.stdout = sys.__stdout__  # Restaura o stdout original
    return buffer.getvalue()

# Carregar times disponíveis apenas uma vez
def carregar_times_disponiveis():
    """Captura os times disponíveis e armazena globalmente."""
    global TIMES_DISPONIVEIS
    if TIMES_DISPONIVEIS is None:
        TIMES_DISPONIVEIS = capturar_saida(exibir_times_com_numeros)

# Funções de UI
def exibir_mensagem_melhorada(titulo, mensagem, largura=600, altura=400):
    """Exibe uma mensagem em uma nova janela com melhor formatação."""
    janela = ttk.Toplevel()
    janela.title(titulo)
    janela.geometry(f"{largura}x{altura}")
    janela.resizable(False, False)

    texto = ttk.Text(janela, wrap="word", font=("Arial", 12))
    texto.insert("1.0", mensagem)
    texto.configure(state="disabled")  # Torna o texto não-editável
    texto.pack(pady=10, padx=10, fill=BOTH, expand=YES)

    scrollbar = ttk.Scrollbar(janela, orient="vertical", command=texto.yview)
    texto.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    btn_ok = ttk.Button(janela, text="Fechar", command=janela.destroy, bootstyle=SUCCESS)
    btn_ok.pack(pady=10)

def mostrar_resultado_parcial_ui():
    atualizar_resultado_parcial()
    calcular_classificacao()
    resultados = capturar_saida(exibir_classificacao)
    if resultados.strip():
        exibir_mensagem_melhorada("Resultado Parcial", resultados, largura=600, altura=400)
    else:
        exibir_mensagem_melhorada("Erro", "Nenhum resultado disponível.")

def listar_rodadas_ui():
    rodadas = capturar_saida(listar_partidas)
    if rodadas.strip():
        exibir_mensagem_melhorada("Rodadas", rodadas, largura=600, altura=400)
    else:
        exibir_mensagem_melhorada("Erro", "Nenhuma rodada encontrada.")

def ver_rodada_especifica_ui():
    def buscar_rodada():
        rodada = entry_rodada.get()
        if not rodada.isdigit():
            exibir_mensagem_melhorada("Erro", "Por favor, insira um número válido para a rodada.")
            return
        jogos = capturar_saida(ver_rodada_especifica, int(rodada))
        if jogos.strip():
            exibir_mensagem_melhorada(f"Rodada {rodada}", jogos, largura=600, altura=400)
        else:
            exibir_mensagem_melhorada("Erro", f"Nenhum jogo encontrado para a rodada {rodada}.")

    janela = criar_janela("Ver Rodada Específica")
    entry_rodada = adicionar_entrada(janela, "Número da Rodada")
    btn_buscar = ttk.Button(janela, text="Buscar", command=buscar_rodada, bootstyle=INFO)
    btn_buscar.pack(pady=10)

def exibir_times_popup():
    """Exibe os times disponíveis em um popup."""
    carregar_times_disponiveis()  # Garante que os times estão carregados
    popup = ttk.Toplevel()
    popup.title("Times Disponíveis")
    popup.geometry("400x600")
    popup.resizable(False, False)

    texto = ttk.Text(popup, wrap="word", font=("Arial", 10))
    texto.insert("1.0", TIMES_DISPONIVEIS or "Nenhum time disponível.")
    texto.configure(state="disabled")  # Torna o texto não-editável
    texto.pack(pady=10, padx=10, fill=BOTH, expand=YES)

    scrollbar = ttk.Scrollbar(popup, orient="vertical", command=texto.yview)
    texto.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side=RIGHT, fill=Y)

    btn_fechar = ttk.Button(popup, text="Fechar", command=popup.destroy, bootstyle=SUCCESS)
    btn_fechar.pack(pady=10)

def cadastrar_jogo_ui():
    """Janela para cadastro de jogo."""
    def salvar_jogo():
        rodada = entry_rodada.get()
        numero_jogo = entry_numero.get()
        time_casa = entry_time_casa.get()
        time_visitante = entry_time_visitante.get()
        data = entry_data.get()
        hora = entry_hora.get()
        estadio = entry_estadio.get()
        gols_casa = entry_gols_casa.get()
        gols_visitante = entry_gols_visitante.get()

        try:
            adicionar_jogo_completo(
                rodada, numero_jogo, time_casa, time_visitante, data, hora, estadio, int(gols_casa), int(gols_visitante)
            )
            exibir_mensagem_melhorada("Sucesso", "Jogo cadastrado com sucesso!")
            janela.destroy()  # Fecha a janela após sucesso
        except ValueError:
            exibir_mensagem_melhorada("Erro", "Por favor, insira valores válidos.")
        except Exception as e:
            exibir_mensagem_melhorada("Erro", f"Ocorreu um erro: {str(e)}")

    # Criar a janela de cadastro
    janela = criar_janela("Cadastrar Jogo")
    janela.geometry("500x600")

    # Botão para exibir times disponíveis
    btn_exibir_times = ttk.Button(janela, text="Exibir Times Disponíveis", command=exibir_times_popup, bootstyle=INFO)
    btn_exibir_times.pack(pady=10)

    # Seção: Informações do Jogo
    frame_info = ttk.LabelFrame(janela, text="Informações do Jogo", padding=10, bootstyle="primary")
    frame_info.pack(fill=X, padx=10, pady=10)

    entry_rodada = adicionar_entrada(frame_info, "Rodada")
    entry_numero = adicionar_entrada(frame_info, "Número do Jogo")
    entry_time_casa = adicionar_entrada(frame_info, "Time Casa")
    entry_time_visitante = adicionar_entrada(frame_info, "Time Visitante")
    entry_data = adicionar_entrada(frame_info, "Data (dd/mm/aaaa)")
    entry_hora = adicionar_entrada(frame_info, "Hora (hh:mm)")
    entry_estadio = adicionar_entrada(frame_info, "Estádio")

    # Seção: Placar
    frame_placar = ttk.LabelFrame(janela, text="Placar", padding=10, bootstyle="warning")
    frame_placar.pack(fill=X, padx=10, pady=10)

    entry_gols_casa = adicionar_entrada(frame_placar, "Gols Time Casa")
    entry_gols_visitante = adicionar_entrada(frame_placar, "Gols Time Visitante")

    # Botão: Salvar
    btn_salvar = ttk.Button(janela, text="Salvar", command=salvar_jogo, bootstyle=SUCCESS)
    btn_salvar.pack(pady=20)

def editar_jogo_ui():
    # Função para editar um jogo existente
    # Função para editar um jogo existente
    def buscar_jogo():
        rodada = entry_rodada.get()
        numero_jogo = entry_numero.get()
        if not rodada.isdigit() or not numero_jogo.isdigit():
            exibir_mensagem_melhorada("Erro", "Rodada e número do jogo devem ser números.")
            return

        janela_edicao = criar_janela(f"Editar Jogo: Rodada {rodada}, Jogo {numero_jogo}")
        opcoes = ["1 - Apagar Jogo", "2 - Time Casa", "3 - Time Visitante", "4 - Data", "5 - Hora", "6 - Estádio", "7 - Gols Time Casa", "8 - Gols Time Visitante"]
        combo_opcoes = ttk.Combobox(janela_edicao, values=opcoes, state="readonly")
        combo_opcoes.set("Selecione uma opção")
        combo_opcoes.pack(pady=10)

        def salvar_edicao():
            opcao = combo_opcoes.get()
            novo_valor = entry_valor.get()
            if not opcao or opcao == "Selecione uma opção":
                exibir_mensagem_melhorada("Erro", "Você deve selecionar uma opção válida.")
                return

            campo = opcao.split(" - ")[0]
            if campo == "1":  # Apagar Jogo
                editar_jogo(int(rodada), int(numero_jogo), campo, None)
                exibir_mensagem_melhorada("Sucesso", f"Jogo da Rodada {rodada}, Número {numero_jogo} apagado com sucesso.")
                janela_edicao.destroy()
                return
            if opcao == "Apagar Jogo":
                editar_jogo(int(rodada), int(numero_jogo), opcao, None)
                exibir_mensagem_melhorada("Sucesso", f"Jogo da Rodada {rodada}, Número {numero_jogo} apagado com sucesso.")
                janela_edicao.destroy()
                return

            editar_jogo(int(rodada), int(numero_jogo), campo, novo_valor)
            exibir_mensagem_melhorada("Sucesso", f"{opcao} atualizado para {novo_valor}.")
            janela_edicao.destroy()

        entry_valor = adicionar_entrada(janela_edicao, "Novo Valor")
        btn_salvar = ttk.Button(janela_edicao, text="Salvar", command=salvar_edicao, bootstyle=SUCCESS)
        btn_salvar.pack(pady=10)

    janela = criar_janela("Editar Jogo")
    entry_rodada = adicionar_entrada(janela, "Rodada")
    entry_numero = adicionar_entrada(janela, "Número do Jogo")
    btn_buscar = ttk.Button(janela, text="Buscar", command=buscar_jogo, bootstyle=INFO)
    btn_buscar.pack(pady=10)

def ver_jogos_time_ui():
    """Janela para selecionar um time e ver seus jogos."""
    def buscar_jogos():
        time_selecionado = combo_times.get()
        if not time_selecionado or time_selecionado == "Selecione um Time":
            exibir_mensagem_melhorada("Erro", "Por favor, selecione um time válido.")
            return

        # Buscar o ID do time correspondente
        time_id = None
        for linha in TIMES_DISPONIVEIS.splitlines():
            if ": " in linha:
                id_, nome = linha.split(": ", 1)
                if nome.strip() == time_selecionado.strip():
                    time_id = id_
                    break

        if not time_id:
            exibir_mensagem_melhorada("Erro", f"ID do time {time_selecionado} não encontrado.")
            return

        # Usar o ID do time para buscar os jogos
        jogos = capturar_saida(ver_jogos_time, time_id)
        if jogos.strip():
            exibir_mensagem_melhorada(f"Jogos do {time_selecionado}", jogos, largura=600, altura=400)
        else:
            exibir_mensagem_melhorada("Erro", f"Nenhum jogo encontrado para o time {time_selecionado}.")

    # Criar a janela
    janela = criar_janela("Ver Jogos de um Time Específico")

    # Dropdown para selecionar o time
    carregar_times_disponiveis()
    times = [linha.split(": ", 1)[1] for linha in TIMES_DISPONIVEIS.splitlines() if ": " in linha]

    combo_times = ttk.Combobox(janela, values=["Selecione um Time"] + times, state="readonly")
    combo_times.set("Selecione um Time")
    combo_times.pack(pady=10)

    # Botão para buscar jogos
    btn_buscar = ttk.Button(janela, text="Buscar", command=buscar_jogos, bootstyle=INFO)
    btn_buscar.pack(pady=10)

def criar_janela(titulo):
    janela = ttk.Toplevel()
    janela.title(titulo)
    janela.geometry("400x400")
    return janela

def adicionar_entrada(frame, label_text):
    frame_entry = ttk.Frame(frame)
    frame_entry.pack(fill=X, pady=5)
    label = ttk.Label(frame_entry, text=label_text, width=20, anchor=W)
    label.pack(side=LEFT)
    entry = ttk.Entry(frame_entry)
    entry.pack(fill=X, expand=YES, side=LEFT, padx=5)
    return entry

def criar_interface_grafica():
    """Cria a interface gráfica principal."""
    # Captura inicial dos times disponíveis
    carregar_times_disponiveis()

    app = ttk.Window(themename="superhero")
    app.title("Gerenciamento de Jogos de Futebol")
    app.geometry("800x600")

    frame_principal = ttk.Frame(app, padding=20)
    frame_principal.pack(fill=BOTH, expand=YES)

    titulo = ttk.Label(frame_principal, text="Sistema de Gerenciamento de Futebol", font=("Arial", 20, "bold"))
    titulo.pack(pady=10)

    botoes_frame = ttk.Frame(frame_principal)
    botoes_frame.pack(pady=20, fill=X)

    # Botões existentes
    ttk.Button(botoes_frame, text="Mostrar Resultado Parcial", command=mostrar_resultado_parcial_ui, bootstyle=PRIMARY).pack(fill=X, pady=5)
    ttk.Button(botoes_frame, text="Ver Rodadas", command=listar_rodadas_ui, bootstyle=SUCCESS).pack(fill=X, pady=5)
    ttk.Button(botoes_frame, text="Ver Rodada Específica", command=ver_rodada_especifica_ui, bootstyle=INFO).pack(fill=X, pady=5)
    ttk.Button(botoes_frame, text="Cadastrar Jogo", command=cadastrar_jogo_ui, bootstyle=DANGER).pack(fill=X, pady=5)
    ttk.Button(botoes_frame, text="Editar Jogo", command=editar_jogo_ui, bootstyle=SECONDARY).pack(fill=X, pady=5)

    # Novo botão: Ver Jogos de um Time Específico
    ttk.Button(botoes_frame, text="Ver Jogos de um Time Específico", command=ver_jogos_time_ui, bootstyle=WARNING).pack(fill=X, pady=5)

    ttk.Button(botoes_frame, text="Sair", command=app.quit, bootstyle=DARK).pack(fill=X, pady=5)

    rodape = ttk.Label(frame_principal, text="Segundo Período - Engenharia de Software", font=("Arial", 15))
    rodape.pack(side=BOTTOM, pady=10)

    app.mainloop()

if __name__ == "__main__":
    criar_interface_grafica()
